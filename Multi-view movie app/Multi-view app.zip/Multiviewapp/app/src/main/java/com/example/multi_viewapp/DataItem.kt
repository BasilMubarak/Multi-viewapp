package com.example.multi_viewapp

data class DataItem (
    val title   :   String,
    val desc : String?,
    val poster : Int?,
    val logo : Int?
)
